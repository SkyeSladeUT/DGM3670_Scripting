import ToolBox

tb = ToolBox.Toolbox()

tb.create()